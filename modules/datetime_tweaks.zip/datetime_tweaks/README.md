# Date time tweaks
Tweaks for DateTime field in Drupal 8 to support human date formats in browsers that don't support type=date HTML5 element

[See the blog post](https://www.previousnext.com.au/blog/making-drupal-8-datetime-widgets-use-human-formats) for more information.
